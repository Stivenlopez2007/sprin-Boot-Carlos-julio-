package com.sena.helloworld.dto;

public class Response {
	private String message;
	
	public String getMessage() {
		return this.message;
	}
	public void setMessage(String message) {
		this.message=message;
	}
}
