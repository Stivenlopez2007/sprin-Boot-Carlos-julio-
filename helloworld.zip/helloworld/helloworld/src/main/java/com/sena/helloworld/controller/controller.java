package com.sena.helloworld.controller;
import org.springframework.web.bind.annotation.RestController;

import com.sena.helloworld.dto.PersonDTO;
import com.sena.helloworld.dto.response;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


@RestController
public class controller {
    
@GetMapping("/hello")
public String hello () {
    return ("Hello World, mamahuevo");
}

@GetMapping("/buenas")
public ResponseEntity<response> buenas () {
    response response = new response();
    response.setMessage("Buenas tardes");
    return new ResponseEntity<>(response, HttpStatus.OK);
}

@GetMapping("/saludo/{nombre}")
public ResponseEntity<response> saludo (@PathVariable String nombre) {
    response response = new response();
    response.setMessage("Buenas tardes" + nombre);
    return new ResponseEntity<>(response, HttpStatus.OK);
}
@PostMapping("/shishi")
public ResponseEntity<response> saludo (@RequestBody PersonDTO person) {
    response response = new response();
    response.setMessage("Que lo que quieres tú? maldito mamahuevo" + 
    " Nombre " + person.getNombre() + 
    " Apellido " + person.getApellido() + 
    " Edad " + person.getEdad()
    );
    return new ResponseEntity<>(response, HttpStatus.OK);
}
}

